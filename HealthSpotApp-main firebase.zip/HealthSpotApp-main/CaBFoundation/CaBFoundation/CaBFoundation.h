//
//  CaBFoundation.h
//  CaBFoundation
//
//  Created by Oparin Oleg on 25.06.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for CaBFoundation.
FOUNDATION_EXPORT double CaBFoundationVersionNumber;

//! Project version string for CaBFoundation.
FOUNDATION_EXPORT const unsigned char CaBFoundationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CaBFoundation/PublicHeader.h>


