import CaBRiblets

final class HealthActivityStatisticsTrackerRouter: BaseRouter {}
