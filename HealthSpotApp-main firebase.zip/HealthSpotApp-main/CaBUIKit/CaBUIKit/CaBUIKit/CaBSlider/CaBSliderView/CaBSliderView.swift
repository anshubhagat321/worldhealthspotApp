import UIKit

class CaBSliderView: UIView {
    
    @IBOutlet private var slider: CaBSlider!

}
