import UIKit

// MARK: - General Protocol

public protocol CaBUIControl {

    func apply(configuration: CaBUIConfiguration)

}
