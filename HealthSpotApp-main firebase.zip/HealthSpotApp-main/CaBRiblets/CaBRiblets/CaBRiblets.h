//
//  CaBRiblets.h
//  CaBRiblets
//
//  Created by Oparin Oleg on 01.02.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for CaBRiblets.
FOUNDATION_EXPORT double CaBRibletsVersionNumber;

//! Project version string for CaBRiblets.
FOUNDATION_EXPORT const unsigned char CaBRibletsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CaBRiblets/PublicHeader.h>


