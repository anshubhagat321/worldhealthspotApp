//
//  CaBAuthorization.h
//  CaBAuthorization
//
//  Created by Oparin Oleg on 06.02.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for CaBAuthorization.
FOUNDATION_EXPORT double CaBAuthorizationVersionNumber;

//! Project version string for CaBAuthorization.
FOUNDATION_EXPORT const unsigned char CaBAuthorizationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CaBAuthorization/PublicHeader.h>


